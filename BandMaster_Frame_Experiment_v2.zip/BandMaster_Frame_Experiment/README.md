# BandMaster — isolated two-material responsive experiment (revision 2)

Two separate PNG material plates and native Godot scenes: `scene/flightcase.tscn` and `scene/notepaper.tscn`. Both now include five role tabs, two canonical identity demo records, six passive attribute meters, recruit/remove with refund, talent display, roster feedback, keyboard-focusable buttons, and distinct narrow (<700px) versus landscape layouts. The test dataset is an isolated demonstration, not a substitute for the production catalogue. No production save writes.

## Run and validate

Open `project.godot` with Godot 4.x and run each scene. Test 390x844, 720x1280, 1280x720 and 1600x900 using Project > Project Settings > Display > Window or the editor viewport. The responsive breakpoint is 700px: narrow screens stack the candidate and dossier regions, display the selected candidate only, reduce tab typography and increase portrait priority. Wide screens display a two-column candidate list and dossier.

Run the native smoke test from this folder:

`godot --headless --path . --script res://tests/scene_smoke.gd`

It tests both scenes at all four resolutions, canonical Nia selection, six meters, recruit/remove refunds and the layout breakpoint. Capture native screenshots only after running Godot with a display; headless tests do not establish visual fidelity.

## Important quality limits

The two background plates were generated locally with Pillow; they are **not** photographed, approved or production-ready. The native controls remain intentionally plain. The plates are 1280x720 and use cover cropping on portrait displays; this preserves aspect ratio but **does not establish a proper phone material composition**. This is a structural prototype, not a successful visual proof.

This environment has no Godot binary and no network access to install one. Therefore the scene smoke test has been authored but **not executed**; parse/import/runtime status remains unverified. Do not treat these files as native Godot screenshots or a passed QA gate.

No GitHub changes or production saves were made. This local package is independent of PR #199 and does not supersede the recovery ledger.
