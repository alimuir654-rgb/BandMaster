extends Control
## Isolated responsive material experiment. No production save access.
@export_enum("flightcase", "notepaper") var material: String = "flightcase"
const CANDIDATES := [
    {"id":"alex", "name":"Alex Vale", "role":"Vocals", "cost":40, "stats":[8,7,6,8,8,6]},
    {"id":"nia_griffiths", "name":"Nia Griffiths", "role":"Vocals", "cost":45, "stats":[8,6,9,6,9,7]}
]
const ROLES := ["VOCALS", "GUITAR", "BASS", "DRUMS", "KEYS"]
const STAT_NAMES := ["VOCALS", "SONGWRITING", "STAGE", "RELIABILITY", "CHEMISTRY", "CREATIVITY"]
var selected := 0
var talent := 200
var roster: Dictionary = {}
var portrait: PanelContainer
var heading: Label
var details: Label
var budget: Label
var status: Label
var stat_rows: VBoxContainer
var candidate_buttons: Array[Button] = []
var tabs: Array[Button] = []
var content: Control
var mobile := false
var background: TextureRect
var root_margin: MarginContainer
var body: BoxContainer
var roster_button: Button
var recruit_button: Button

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background = TextureRect.new()
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.texture = load("res://assets/%s_frame_1280x720.png" % material)
    background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(background)
    root_margin = MarginContainer.new()
    root_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root_margin)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 8)
    root_margin.add_child(layout)
    var top := HBoxContainer.new()
    layout.add_child(top)
    heading = Label.new()
    heading.text = "RECRUITMENT · " + material.to_upper()
    heading.add_theme_font_size_override("font_size", 22)
    heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(heading)
    budget = Label.new()
    top.add_child(budget)
    var role_strip := HBoxContainer.new()
    role_strip.add_theme_constant_override("separation", 4)
    layout.add_child(role_strip)
    for i in ROLES.size():
        var tab := Button.new()
        tab.text = ROLES[i]
        tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        tab.custom_minimum_size.y = 46
        tab.focus_mode = Control.FOCUS_ALL
        tab.pressed.connect(_select_role.bind(i))
        role_strip.add_child(tab)
        tabs.append(tab)
    body = HBoxContainer.new()
    body.add_theme_constant_override("separation", 12)
    body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    layout.add_child(body)
    var candidates := VBoxContainer.new()
    candidates.name = "Candidates"
    candidates.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    body.add_child(candidates)
    for i in CANDIDATES.size():
        var button := Button.new()
        button.text = CANDIDATES[i].name
        button.custom_minimum_size.y = 48
        button.focus_mode = Control.FOCUS_ALL
        button.pressed.connect(_select.bind(i))
        candidates.add_child(button)
        candidate_buttons.append(button)
    var dossier := VBoxContainer.new()
    dossier.name = "Dossier"
    dossier.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    body.add_child(dossier)
    portrait = PanelContainer.new()
    portrait.custom_minimum_size = Vector2(160, 105)
    portrait.size_flags_vertical = Control.SIZE_EXPAND_FILL
    dossier.add_child(portrait)
    var missing := Label.new()
    missing.text = "PORTRAIT MASTER MISSING\nART GATE BLOCKED"
    missing.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    missing.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    portrait.add_child(missing)
    details = Label.new()
    details.add_theme_font_size_override("font_size", 19)
    dossier.add_child(details)
    stat_rows = VBoxContainer.new()
    stat_rows.add_theme_constant_override("separation", 2)
    dossier.add_child(stat_rows)
    var actions := HBoxContainer.new()
    actions.add_theme_constant_override("separation", 8)
    layout.add_child(actions)
    recruit_button = Button.new()
    recruit_button.custom_minimum_size.y = 50
    recruit_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    recruit_button.pressed.connect(_recruit_or_remove)
    actions.add_child(recruit_button)
    roster_button = Button.new()
    roster_button.custom_minimum_size.y = 50
    roster_button.text = "ROSTER"
    roster_button.pressed.connect(_show_roster)
    actions.add_child(roster_button)
    status = Label.new()
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    layout.add_child(status)
    resized.connect(_apply_layout)
    _select_role(0)
    _select(0)
    _apply_layout()

func _apply_layout() -> void:
    var narrow := size.x < 700
    mobile = narrow
    root_margin.add_theme_constant_override("margin_left", 18 if narrow else 65)
    root_margin.add_theme_constant_override("margin_right", 18 if narrow else 65)
    root_margin.add_theme_constant_override("margin_top", 28 if narrow else 66)
    root_margin.add_theme_constant_override("margin_bottom", 28 if narrow else 65)
    body.vertical = narrow
    var candidates := body.get_node("Candidates") as VBoxContainer
    candidates.custom_minimum_size = Vector2(0, 102 if narrow else 0)
    for button in candidate_buttons:
        button.visible = not narrow or button == candidate_buttons[selected]
    portrait.custom_minimum_size.y = 135 if narrow else 185
    heading.add_theme_font_size_override("font_size", 16 if narrow else 22)
    for tab in tabs:
        tab.add_theme_font_size_override("font_size", 10 if narrow else 15)
    roster_button.text = "ROSTER" if narrow else "VIEW ROSTER"

func _select_role(index: int) -> void:
    for i in tabs.size():
        tabs[i].disabled = i == index
    if index != 0:
        status.text = "Only vocals are populated in this isolated material test."
    else:
        status.text = "Demo catalogue · no production save writes"

func _select(index: int) -> void:
    selected = index
    for i in candidate_buttons.size():
        candidate_buttons[i].disabled = i == index
    var candidate: Dictionary = CANDIDATES[index]
    details.text = "%s · %s · %d talent" % [candidate.name, candidate.role, candidate.cost]
    for child in stat_rows.get_children():
        child.queue_free()
    for i in STAT_NAMES.size():
        var line := HBoxContainer.new()
        stat_rows.add_child(line)
        var label := Label.new()
        label.text = STAT_NAMES[i]
        label.custom_minimum_size.x = 112
        line.add_child(label)
        var meter := ProgressBar.new()
        meter.min_value = 0
        meter.max_value = 10
        meter.value = candidate.stats[i]
        meter.mouse_filter = Control.MOUSE_FILTER_IGNORE
        meter.focus_mode = Control.FOCUS_NONE
        meter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        meter.custom_minimum_size.y = 19
        line.add_child(meter)
    _update_budget()
    if mobile:
        _apply_layout()

func _update_budget() -> void:
    budget.text = "TALENT %d" % talent
    var candidate: Dictionary = CANDIDATES[selected]
    var recruited := roster.has(candidate.id)
    recruit_button.text = "REMOVE" if recruited else "RECRUIT · %d" % candidate.cost
    recruit_button.disabled = not recruited and talent < candidate.cost

func _recruit_or_remove() -> void:
    var candidate: Dictionary = CANDIDATES[selected]
    if roster.has(candidate.id):
        roster.erase(candidate.id)
        talent += candidate.cost
        status.text = "%s removed · talent refunded" % candidate.name
    elif talent >= candidate.cost:
        roster[candidate.id] = true
        talent -= candidate.cost
        status.text = "%s recruited (isolated demo only)" % candidate.name
    _update_budget()

func _show_roster() -> void:
    var names: Array[String] = []
    for candidate in CANDIDATES:
        if roster.has(candidate.id):
            names.append(candidate.name)
    status.text = "ROSTER: " + (", ".join(names) if not names.is_empty() else "empty")
