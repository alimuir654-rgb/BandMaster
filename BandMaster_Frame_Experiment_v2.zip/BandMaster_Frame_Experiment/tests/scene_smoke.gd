extends SceneTree
# Run: godot --headless --path . --script res://tests/scene_smoke.gd
func _initialize() -> void:
    call_deferred("run_tests")

func run_tests() -> void:
    for material in ["flightcase", "notepaper"]:
        var scene: PackedScene = load("res://scene/%s.tscn" % material)
        assert(scene != null, "Scene must import")
        for viewport_size in [Vector2i(390,844), Vector2i(720,1280), Vector2i(1280,720), Vector2i(1600,900)]:
            var window := Window.new()
            window.size = viewport_size
            root.add_child(window)
            var instance := scene.instantiate()
            window.add_child(instance)
            await process_frame
            await process_frame
            assert(instance.mobile == (viewport_size.x < 700), "Breakpoint mismatch")
            assert(instance.tabs.size() == 5)
            assert(instance.stat_rows.get_child_count() == 6)
            assert(instance.talent == 200)
            instance._select(1)
            assert(instance.details.text.contains("Nia Griffiths"))
            instance._recruit_or_remove()
            assert(instance.talent == 155)
            instance._recruit_or_remove()
            assert(instance.talent == 200)
            assert(instance.roster.is_empty())
            print("PASS %s %sx%s" % [material, viewport_size.x, viewport_size.y])
            window.queue_free()
            await process_frame
    quit(0)
