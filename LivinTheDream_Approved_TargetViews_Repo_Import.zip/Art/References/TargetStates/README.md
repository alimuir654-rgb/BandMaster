# Livin’ The Dream — approved scene target views (27 October 2026)

**BandMaster** is the internal repo/project name; **Livin’ The Dream** is the game/player-facing title. The PNGs are owner-approved aspirational references, **not** Godot screenshots or runtime assets. Samples in the concepts (venues, maps, dates, wallets, cash) are decorative and not authoritative game state. Treat names and labels in these images as art direction, not shippable data.

## Targets
- `01_Songwriting_Rotary_Approved.png`: DAY songwriting, premium brushed hardware, exact per-value rotary rings, sympathetic inset console/housing. Graphite metal should look *built into* its enclosure.
- `02_Tour_Planning_Paper_Approved.png`: DAY road-trip planning: venue itinerary sheet, clipped notes, paper/tape/pencil, checklist, route strip, mileage/budget and next-show ticket. Dynamic text/cards must be Godot nodes; do not bake invented distance or US venue names into gameplay.
- `03_Gig_Night_Showboard_Approved.png`: NIGHT showboard: setlist edits, stage timings, cues, passes, venue contact, pen scribbles. DUSK load-in must bridge bright DAY to illuminated NIGHT. Gig timing and single payout must remain model-authoritative.

## Approval versus implementation
These images establish *target visual language and quality* only. Actual Godot scene captures are required before a family earns a quality PASS. No app state or gameplay was changed by this archive.

## Visual acceptance
Compare original concept side-by-side with real Godot 390×844, 720×1280, 1280×720 and 1600×900 captures. Look for material depth, photo/grain/tape/hardware quality; grouping; 44px controls; readable labels and overlays; believable paper layers; no flat SVG hero stand-ins; no residual lamp lighting or ghost pixels; keyboard focus; reduced motion; no save/write and model-side isolation in proofs.

Provenance: original images created in the 27 October 2026 owner conversation specifically for BandMaster scene visual development. Distinguish these from external third-party artwork. Verify source licences for all other added imagery.
