#!/usr/bin/env python3
from pathlib import Path
from hashlib import sha256
import json,struct
root=Path(__file__).resolve().parents[1]
folder=root/'Art/References/TargetStates'
m=json.loads((folder/'TARGET_VIEW_MANIFEST.json').read_text())
assert m['game_title']=='Livin’ The Dream'
assert len(m['files'])==3
for name,meta in m['files'].items():
 p=folder/name; blob=p.read_bytes()
 assert sha256(blob).hexdigest()==meta['sha256'],f'Mismatched source: {name}'
 assert blob[:8]==bytes.fromhex('89504e470d0a1a0a'),f'Not PNG: {name}'
 w,h=struct.unpack('>II',blob[16:24]); assert w>=1200 and h>=650,(name,w,h)
 print(name,w,h)
print('TARGET-VIEW SOURCE GATE PASS: 3 approved concept PNGs; not Godot runtime proof')
